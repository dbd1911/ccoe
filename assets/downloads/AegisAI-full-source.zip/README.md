# Aegis.AI — Executive Decision Support & Risk Management Suite

A self-contained web app: a React front end for monitoring cyber risk posture,
optimizing security budgets, and making authorization decisions, plus a small
Node/Express back end that talks to the AI model **of your choice** (Anthropic,
Google Gemini, Ask Sage, OpenAI, or any OpenAI-compatible / self-hosted model).

The browser never holds an API key. All AI calls go through your own server,
which reads the key from a local `.env` file and forwards the request to the
provider you configured. **Switching models is a two-line change in `.env` — no
code edits.**

---

## 1. Prerequisites

- **Node.js 20 or newer** (check with `node --version`).
- One API key for whichever model you want to use (optional — the app runs
  fully without AI; only the "AI Authorization Memo" feature needs a key).

---

## 2. Quick start (development)

```bash
# 1. install dependencies
npm install

# 2. create your config from the template
cp .env.example .env        # Windows: copy .env.example .env

# 3. open .env and set a provider + key (see section 4). To try the UI
#    without AI, you can skip this and come back later.

# 4. run both the API and the web app together
npm run dev
```

Then open **http://localhost:5173**.

`npm run dev` starts two processes:
- the **API** on `http://localhost:8787`
- the **web app** on `http://localhost:5173` (it automatically forwards
  `/api/...` calls to the API, so you only ever open one URL).

---

## 3. Production / running in another environment

Build the front end once, then run a single Node process that serves both the
app and the API on one port:

```bash
npm run build      # outputs static files to ./dist
npm start          # serves app + API on http://localhost:8787
```

Open **http://localhost:8787**. Set `PORT` in `.env` to change the port. This
single-process mode is the easiest way to drop the app into a container, VM, or
internal server — there is nothing else to run.

---

## 4. Choosing and configuring a model

Edit `.env`. Set `AI_PROVIDER`, the matching `*_API_KEY`, and (optionally)
`AI_MODEL`. Pick **one** block:

### Anthropic (Claude)
```env
AI_PROVIDER=anthropic
AI_MODEL=claude-sonnet-4-6
ANTHROPIC_API_KEY=sk-ant-...
```

### Google Gemini
```env
AI_PROVIDER=gemini
AI_MODEL=gemini-2.5-flash
GEMINI_API_KEY=...
```
Get a key at https://aistudio.google.com/apikey. Any current Gemini model name
works (`gemini-2.5-pro`, newer 3.x models, etc.).

### Ask Sage  *(recommended path — uses its OpenAI-compatible endpoint)*
```env
AI_PROVIDER=asksage
AI_MODEL=gpt-4.1-mini
ASKSAGE_API_KEY=...
# If your organization uses a specific Ask Sage instance, set its base URL.
# Only the middle segment changes per deployment:
# ASKSAGE_BASE_URL=https://api.asksage.ai/server/openai/v1
```

### Ask Sage  *(native — only if you need personas / datasets / live retrieval)*
```env
AI_PROVIDER=asksage-native
AI_MODEL=gpt-4.1-mini
ASKSAGE_API_KEY=...
ASKSAGE_PERSONA=1
ASKSAGE_DATASET=all      # comma-separated dataset names
ASKSAGE_LIVE=0           # set 1 to allow live web retrieval
```

### OpenAI, or any OpenAI-compatible / self-hosted model
This is the "any model I choose" escape hatch. Point `OPENAI_BASE_URL` at the
endpoint and set the model name:
```env
AI_PROVIDER=openai
AI_MODEL=gpt-4o-mini
OPENAI_API_KEY=sk-...
# OpenAI:     OPENAI_BASE_URL=https://api.openai.com/v1   (default)
# OpenRouter: OPENAI_BASE_URL=https://openrouter.ai/api/v1
# Ollama:     OPENAI_BASE_URL=http://localhost:11434/v1   (key can be any text)
# LM Studio:  OPENAI_BASE_URL=http://localhost:1234/v1
# vLLM/TGI:   OPENAI_BASE_URL=http://your-host:8000/v1
```

**To switch models later:** change `AI_PROVIDER` and `AI_MODEL`, save, restart
the server. Nothing else changes. The sidebar shows the active model, and
`GET /api/ai/health` reports it.

---

## 5. How the swap works (for developers)

Every AI request in the app calls one endpoint: `POST /api/ai/complete` with a
neutral shape:

```json
{ "system": "…", "messages": [{ "role": "user", "content": "…" }],
  "temperature": 0.3, "maxTokens": 700 }
```

The server (`server/providers/index.js`) reads `AI_PROVIDER` and hands the
request to one adapter. Each adapter (`anthropic.js`, `gemini.js`, `openai.js`,
`asksage.js`) translates that neutral shape into the vendor's format and
normalizes the reply back to `{ text }`. The React app has zero vendor-specific
code. To add a new provider, drop in one adapter file and one `case` in the
registry.

---

## 6. Using the application

- **Landing** — click **ENTER** to open the suite.
- **Sidebar** — switch modules; the **Active System** selector at the bottom
  sets which system the per-system modules operate on.
- **Dashboard** — portfolio KPIs, risk distribution, connectivity mix, average
  risk by program office, and authorizations expiring within 180 days.
- **System Registry** — search/filter the inventory; **Edit**, **Delete**, jump
  to **Risk Posture**, or run an **SSAV Review** (standalone systems).
  **Register System** adds a new one (changes persist for the session).
- **Risk Posture Pro** — tap hygiene controls to cycle Addressed → Risk Accepted
  → Not Addressed; the gauge recomputes live. Use the **what-if sliders** to see
  how more MITRE compliance or less exposure buys down risk, pick an
  **authorization type** for a recommendation, and click **Generate Memo** for an
  AI-written executive narrative (requires a configured model).
- **Optimization Engine** — drag the budget slider; the greedy/knapsack selector
  picks the highest risk-reduction-per-dollar mitigations that fit. Expand
  **ROSI Methodology** for the SLE/ALE/ROSI math.
- **Zero-Scan Wizard** — step through Access Control, Disaster Recovery, and
  Audit questions to generate an SSAV recommendation.

> Data is synthetic and held in memory; it resets on refresh. See section 8 to
> wire it to a real database.

---

## 7. Security notes

- Keep API keys in `.env` only. `.env` is git-ignored; **never commit it**.
- Keys live server-side and are never sent to the browser.
- Before exposing this beyond localhost, add authentication and restrict CORS in
  `server/index.js` to your front-end origin.
- The data is fictional and **not for operational use**.

---

## 8. Project structure & extending

```
aegis-ai/
├─ index.html            # Vite entry
├─ vite.config.js        # dev server + /api proxy
├─ .env.example          # copy to .env
├─ src/
│  ├─ main.jsx           # React mount
│  ├─ App.jsx            # entire UI + risk/optimization logic
│  └─ aiClient.js        # calls the local /api proxy
└─ server/
   ├─ index.js           # Express: /api/ai/* + serves built app
   └─ providers/
      ├─ index.js        # provider registry — the swap point
      ├─ anthropic.js    # Claude adapter
      ├─ gemini.js       # Gemini adapter
      ├─ openai.js       # OpenAI-compatible adapter (OpenAI, Ask Sage, local…)
      └─ asksage.js      # Ask Sage native /query adapter
```

**Add persistent storage (optional):** the front-end data layer is the reducer
in `App.jsx` (actions like `ADD_SYSTEM`, `UPDATE_POAM`). To use a real database,
add REST routes in `server/index.js` backed by SQLite (e.g. `better-sqlite3`)
matching the PRD schema, then replace the reducer dispatches with `fetch` calls
to those routes. The action names already mirror the operations you'd expose.

---

## 9. Troubleshooting

| Symptom | Fix |
|---|---|
| Sidebar says "AI not configured" | Set `AI_PROVIDER` + the matching key in `.env`, then restart the server. |
| "Couldn't reach the model" on Generate | Check the key, the model name is valid for that provider, and (for Ask Sage/local) `*_BASE_URL` matches your instance. The API console prints the exact error. |
| `npm run dev` — port in use | Change `PORT` in `.env` (API) or `server.port` in `vite.config.js` (web). |
| Calls 404 in production | Run `npm run build` before `npm start` so `./dist` exists. |
| Self-hosted model refused | Confirm the server is running and `OPENAI_BASE_URL` ends in `/v1`. |
