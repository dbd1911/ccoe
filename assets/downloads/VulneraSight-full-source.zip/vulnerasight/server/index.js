import "dotenv/config";
import express from "express";
import path from "node:path";
import fs from "node:fs";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.use(express.json({ limit: "8mb" }));

const PORT = process.env.PORT || 8787;

/* ---------------------------------------------------------------------------
   PROVIDER CONFIG
   Pick a provider with AI_PROVIDER. Each preset sets a default base URL, auth
   style, request "shape", and a default model. Any preset value can be
   overridden with AI_BASE_URL / AI_MODEL / AI_API_KEY in your .env.

     anthropic  -> Anthropic Messages API (native shape)
     asksage    -> Ask Sage OpenAI-compatible endpoint (Bearer)   [FedRAMP/IL options]
     gemini     -> Google Gemini OpenAI-compatible endpoint (Bearer)
     openai     -> OpenAI / Azure / any OpenAI-compatible endpoint (Bearer)

   "shape" is the only thing that changes how we build the request and read the
   response. Everything OpenAI-compatible (asksage, gemini, openai) shares one
   adapter. We always normalize the reply back into the Anthropic envelope the
   front end expects, so the UI never changes when you switch providers.
--------------------------------------------------------------------------- */
const PRESETS = {
  anthropic: { shape: "anthropic", base: "https://api.anthropic.com",                          model: "claude-sonnet-4-6" },
  asksage:   { shape: "openai",    base: "https://api.asksage.ai/server/openai/v1",            model: "gpt-4.1-mini" },
  gemini:    { shape: "openai",    base: "https://generativelanguage.googleapis.com/v1beta/openai", model: "gemini-2.5-flash" },
  openai:    { shape: "openai",    base: "https://api.openai.com/v1",                          model: "gpt-4o" },
};

const PROVIDER = (process.env.AI_PROVIDER || "anthropic").toLowerCase();
const preset = PRESETS[PROVIDER] || PRESETS.anthropic;

const SHAPE = preset.shape;
const BASE_URL = (process.env.AI_BASE_URL || process.env.ANTHROPIC_BASE_URL || preset.base).replace(/\/+$/, "");
const MODEL = process.env.AI_MODEL || process.env.CLAUDE_MODEL || preset.model;
const API_KEY = process.env.AI_API_KEY || process.env.ANTHROPIC_API_KEY;

app.get("/api/health", (_req, res) =>
  res.json({ ok: true, provider: PROVIDER, shape: SHAPE, model: MODEL, baseUrl: BASE_URL, keyConfigured: Boolean(API_KEY) })
);

/* Build the upstream request for the configured provider. */
function buildRequest({ system, messages, max_tokens }) {
  if (SHAPE === "anthropic") {
    return {
      url: `${BASE_URL}/v1/messages`,
      headers: { "content-type": "application/json", "x-api-key": API_KEY, "anthropic-version": "2023-06-01" },
      body: { model: MODEL, max_tokens: max_tokens || 8000, system, messages },
    };
  }
  // OpenAI-compatible (asksage / gemini / openai / azure-style)
  const oaiMessages = [];
  if (system) oaiMessages.push({ role: "system", content: system });
  for (const m of messages) {
    const content = typeof m.content === "string"
      ? m.content
      : (Array.isArray(m.content) ? m.content.map((p) => p.text || "").join("\n") : String(m.content ?? ""));
    oaiMessages.push({ role: m.role, content });
  }
  return {
    url: `${BASE_URL}/chat/completions`,
    headers: { "content-type": "application/json", "authorization": `Bearer ${API_KEY}` },
    body: { model: MODEL, max_tokens: max_tokens || 8000, messages: oaiMessages },
  };
}

/* Normalize any provider's reply into the Anthropic envelope:
   { content: [{ type:"text", text }], stop_reason } */
function normalize(status, data) {
  if (status >= 400 || data?.error || data?.type === "error") {
    const message = data?.error?.message || data?.message || `Upstream request failed (HTTP ${status}).`;
    return { status: status >= 400 ? status : 502, payload: { type: "error", error: { message } } };
  }
  if (SHAPE === "anthropic") {
    return { status, payload: data }; // already in the right shape
  }
  const choice = data?.choices?.[0];
  let text = choice?.message?.content ?? "";
  if (Array.isArray(text)) text = text.map((p) => (typeof p === "string" ? p : p?.text || "")).join("\n");
  const stop_reason = choice?.finish_reason === "length" ? "max_tokens" : "end_turn";
  return { status, payload: { content: [{ type: "text", text }], stop_reason, _provider: PROVIDER, _model: MODEL } };
}

app.post("/api/analyze", async (req, res) => {
  if (!API_KEY) {
    return res.status(500).json({
      type: "error",
      error: { message: `Server is missing an API key. Set AI_API_KEY (or ANTHROPIC_API_KEY) in your .env for provider "${PROVIDER}".` },
    });
  }
  try {
    const { system, messages, max_tokens } = req.body || {};
    if (!Array.isArray(messages) || !messages.length) {
      return res.status(400).json({ type: "error", error: { message: "Request must include a non-empty messages array." } });
    }
    const reqSpec = buildRequest({ system, messages, max_tokens });
    const upstream = await fetch(reqSpec.url, {
      method: "POST",
      headers: reqSpec.headers,
      body: JSON.stringify(reqSpec.body),
    });
    let data;
    const raw = await upstream.text();
    try { data = JSON.parse(raw); } catch { data = { error: { message: raw.slice(0, 500) || "Non-JSON response from provider." } }; }
    const { status, payload } = normalize(upstream.status, data);
    res.status(status).json(payload);
  } catch (e) {
    res.status(502).json({ type: "error", error: { message: `Proxy could not reach the ${PROVIDER} endpoint: ` + (e?.message || String(e)) } });
  }
});

// In production, serve the built frontend from the same origin (no CORS needed).
const dist = path.join(__dirname, "..", "dist");
if (fs.existsSync(dist)) {
  app.use(express.static(dist));
  app.get("*", (_req, res) => res.sendFile(path.join(dist, "index.html")));
}

app.listen(PORT, () => {
  console.log(`VulneraSight ${fs.existsSync(dist) ? "(UI + API) " : "API "}on http://localhost:${PORT}  ·  provider=${PROVIDER}  model=${MODEL}`);
  if (!API_KEY) console.warn(`⚠  No API key set — /api/analyze will error until you configure AI_API_KEY for provider "${PROVIDER}".`);
});
