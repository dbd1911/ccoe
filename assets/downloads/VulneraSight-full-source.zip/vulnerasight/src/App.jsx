import React, { useState, useMemo, useRef, useCallback, useEffect } from "react";
import {
  RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar,
  ScatterChart, Scatter, XAxis, YAxis, ZAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, ReferenceArea, Cell,
} from "recharts";
import {
  Shield, Upload, FileCheck2, FileWarning, Radar as RadarIcon, Crosshair,
  SlidersHorizontal, X, Copy, Check, Network, Cpu, HardDrive, AlertOctagon,
  Activity, Layers, ChevronRight, Eye, EyeOff, Download, Loader2, RotateCcw,
} from "lucide-react";

/* ============================== DESIGN TOKENS ============================== */
const STYLES = `
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap');
:root{
  --void:#070C18; --abyss:#0A1224; --panel:#0E1A33; --panel-2:#11203E;
  --line:#1C2C4D; --line-2:#26395f;
  --txt:#E7EDF9; --txt-2:#9DAAC8; --txt-3:#64739A;
  --teal:#2DD4BF; --teal-dim:#11453f; --cyan:#38BDF8;
  --crit:#F4607E; --crit-dim:#3a1422; --high:#FB923C; --high-dim:#3a2412;
  --med:#FBBF24; --med-dim:#352a0e; --low:#34D399; --low-dim:#0f3328;
  --shadow:0 18px 50px -20px rgba(0,0,0,.7);
}
*{box-sizing:border-box}
.vs-root{font-family:'Inter','Segoe UI',system-ui,sans-serif;color:var(--txt);
  background:
    radial-gradient(900px 500px at 78% -8%, rgba(45,212,191,.07), transparent 60%),
    radial-gradient(700px 500px at 5% 4%, rgba(56,189,248,.06), transparent 55%),
    var(--void);
  min-height:100vh; line-height:1.45; -webkit-font-smoothing:antialiased;}
.mono{font-family:'JetBrains Mono',ui-monospace,monospace}
.vs-wrap{max-width:1320px;margin:0 auto;padding:22px 22px 90px}

/* header */
.vs-top{display:flex;align-items:center;gap:14px;padding:6px 2px 20px;flex-wrap:wrap}
.vs-mark{width:42px;height:42px;border-radius:11px;display:grid;place-items:center;
  background:linear-gradient(150deg,var(--teal),#0d8a7c);box-shadow:0 8px 24px -10px rgba(45,212,191,.7);color:#04221d}
.vs-brand{font-weight:800;font-size:19px;letter-spacing:-.02em}
.vs-brand span{color:var(--teal)}
.vs-sub{font-size:11.5px;color:var(--txt-3);letter-spacing:.14em;text-transform:uppercase;margin-top:1px}
.vs-status{margin-left:auto;display:flex;align-items:center;gap:8px;font-size:12px;color:var(--txt-2);
  background:var(--panel);border:1px solid var(--line);padding:7px 13px;border-radius:999px}
.dot{width:7px;height:7px;border-radius:50%;background:var(--teal);box-shadow:0 0 10px var(--teal);animation:pulse 2s infinite}
@keyframes pulse{50%{opacity:.4}}

/* layout */
.grid{display:grid;grid-template-columns:330px 1fr;gap:18px;align-items:start}
@media(max-width:960px){.grid{grid-template-columns:1fr}}
.panel{background:linear-gradient(180deg,var(--panel),var(--abyss));border:1px solid var(--line);
  border-radius:16px;box-shadow:var(--shadow)}
.pad{padding:18px}
.eyebrow{font-size:10.5px;letter-spacing:.16em;text-transform:uppercase;color:var(--txt-3);
  font-weight:700;display:flex;align-items:center;gap:7px;margin:0 0 13px}
.eyebrow .ic{color:var(--teal)}

/* dropzone */
.dz{position:relative;border:1.5px dashed var(--line-2);border-radius:14px;padding:26px 18px;text-align:center;
  background:rgba(17,32,62,.4);transition:.22s;cursor:pointer;overflow:hidden}
.dz:hover,.dz.hot{border-color:var(--teal);background:rgba(45,212,191,.06)}
.dz.hot::after{content:"";position:absolute;inset:-1px;border-radius:14px;
  box-shadow:0 0 0 2px var(--teal), 0 0 30px rgba(45,212,191,.4) inset;animation:pulseB 1.1s infinite}
@keyframes pulseB{50%{opacity:.45}}
.dz .up{width:38px;height:38px;border-radius:11px;display:grid;place-items:center;margin:0 auto 11px;
  background:rgba(45,212,191,.1);color:var(--teal)}
.dz h4{margin:0 0 4px;font-size:14px;font-weight:600}
.dz p{margin:0;font-size:11.5px;color:var(--txt-3)}
.chips{display:flex;gap:8px;margin-top:13px}
.chip{flex:1;display:flex;align-items:center;gap:8px;font-size:11px;padding:8px 10px;border-radius:9px;
  background:var(--abyss);border:1px solid var(--line);color:var(--txt-3);transition:.2s;text-align:left}
.chip.ok{border-color:var(--teal);color:var(--teal);background:var(--teal-dim)}
.chip .lab{font-weight:600;letter-spacing:.04em}
.chip .fn{font-size:9.5px;opacity:.75;display:block;margin-top:1px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:108px}
.shimmer{height:3px;border-radius:3px;margin-top:14px;overflow:hidden;background:var(--line)}
.shimmer i{display:block;height:100%;width:40%;background:linear-gradient(90deg,transparent,var(--teal),transparent);
  animation:slide 1.1s infinite}
@keyframes slide{0%{transform:translateX(-120%)}100%{transform:translateX(320%)}}

/* controls */
.ctrl{margin-bottom:16px}
.ctrl label{display:block;font-size:11px;font-weight:600;color:var(--txt-2);margin-bottom:7px;letter-spacing:.02em}
.sel{width:100%;background:var(--abyss);border:1px solid var(--line);color:var(--txt);font-size:13px;
  padding:11px 12px;border-radius:10px;font-family:inherit;appearance:none;cursor:pointer;
  background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%239DAAC8' stroke-width='2.5'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E");
  background-repeat:no-repeat;background-position:right 12px center}
.sel:focus{outline:none;border-color:var(--teal)}
.connote{font-size:10.5px;color:var(--txt-3);margin-top:6px;display:flex;gap:6px;align-items:center}
.seg{display:flex;gap:6px}
.seg button{flex:1;font:inherit;font-size:12px;font-weight:600;padding:9px 0;border-radius:9px;cursor:pointer;
  background:var(--abyss);border:1px solid var(--line);color:var(--txt-2);transition:.18s}
.seg button.on{background:var(--teal-dim);border-color:var(--teal);color:var(--teal)}
.toggle{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:11px 12px;border-radius:10px;
  background:var(--abyss);border:1px solid var(--line)}
.toggle .t{font-size:12px;font-weight:600}.toggle .d{font-size:10px;color:var(--txt-3);margin-top:1px}
.sw{width:40px;height:22px;border-radius:999px;background:var(--line-2);position:relative;cursor:pointer;transition:.2s;flex:none}
.sw.on{background:var(--teal)}
.sw i{position:absolute;top:2px;left:2px;width:18px;height:18px;border-radius:50%;background:#fff;transition:.2s}
.sw.on i{left:20px}

.btn{width:100%;border:none;font:inherit;font-weight:700;font-size:13.5px;padding:13px;border-radius:11px;cursor:pointer;
  display:flex;align-items:center;justify-content:center;gap:9px;transition:.18s;letter-spacing:.01em}
.btn.primary{background:linear-gradient(150deg,var(--teal),#0e9486);color:#042a24;box-shadow:0 12px 28px -12px rgba(45,212,191,.8)}
.btn.primary:hover{filter:brightness(1.07)}
.btn.primary:disabled{opacity:.45;cursor:not-allowed;filter:none}
.btn.ghost{background:var(--abyss);border:1px solid var(--line);color:var(--txt-2);font-size:12px;padding:9px}
.btn.ghost:hover{border-color:var(--teal);color:var(--teal)}

/* empty / hero */
.hero{display:grid;place-items:center;min-height:480px;text-align:center;padding:30px}
.hero .ring{width:120px;height:120px;border-radius:50%;display:grid;place-items:center;margin-bottom:22px;
  background:radial-gradient(circle,rgba(45,212,191,.14),transparent 70%);position:relative}
.hero .ring::before,.hero .ring::after{content:"";position:absolute;border-radius:50%;border:1px solid var(--line-2)}
.hero .ring::before{inset:-14px;animation:spin 18s linear infinite}
.hero .ring::after{inset:8px;border-style:dashed;border-color:var(--teal);opacity:.35;animation:spin 9s linear infinite reverse}
@keyframes spin{to{transform:rotate(360deg)}}
.hero h2{font-size:23px;font-weight:800;letter-spacing:-.02em;margin:0 0 9px}
.hero p{max-width:430px;color:var(--txt-2);font-size:13.5px;margin:0 0 22px}
.steps{display:flex;gap:10px;flex-wrap:wrap;justify-content:center;max-width:540px}
.step{font-size:11px;color:var(--txt-3);background:var(--panel);border:1px solid var(--line);
  padding:8px 13px;border-radius:999px;display:flex;align-items:center;gap:7px}
.step b{color:var(--teal);font-family:'JetBrains Mono',monospace}

/* exec summary */
.exec{display:grid;grid-template-columns:200px 1fr;gap:18px}
@media(max-width:720px){.exec{grid-template-columns:1fr}}
.gauge{display:grid;place-items:center;padding:8px}
.gauge .num{font-size:13px;font-weight:800;letter-spacing:.04em;text-transform:uppercase}
.gauge svg{transform:rotate(-90deg)}
.exec-body p{margin:0 0 12px;font-size:13px;color:var(--txt-2)}
.exec-body p:last-child{margin-bottom:0}
.exec-body b{color:var(--txt)}
.kv{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px}
.profile-card{flex:1;min-width:120px;padding:12px;border-radius:12px;border:1px solid var(--line);background:var(--abyss);position:relative;overflow:hidden;cursor:default;transition:.2s}
.profile-card.lead{border-color:var(--teal)}
.profile-card .pl{font-size:10px;text-transform:uppercase;letter-spacing:.1em;color:var(--txt-3);font-weight:700;display:flex;align-items:center;gap:6px}
.profile-card .pv{font-size:26px;font-weight:800;margin-top:5px;font-family:'JetBrains Mono',monospace}
.profile-card .bar{height:4px;border-radius:3px;background:var(--line);margin-top:8px;overflow:hidden}
.profile-card .bar i{display:block;height:100%;border-radius:3px;transition:width .7s cubic-bezier(.2,.7,.2,1)}

/* radar */
.split{display:grid;grid-template-columns:1fr 1fr;gap:18px}
@media(max-width:880px){.split{grid-template-columns:1fr}}
.dims{display:flex;flex-direction:column;gap:9px;justify-content:center}
.dimrow{display:grid;grid-template-columns:1fr auto;gap:8px;align-items:center;font-size:11.5px}
.dimrow .dn{color:var(--txt-2)}
.dimrow .track{grid-column:1/-1;height:6px;border-radius:4px;background:var(--line);overflow:hidden}
.dimrow .track i{display:block;height:100%;border-radius:4px;background:linear-gradient(90deg,var(--cyan),var(--teal));transition:width .6s}
.dimrow .dv{font-family:'JetBrains Mono',monospace;color:var(--txt);font-weight:600}

/* roadmap */
.tabbar{display:flex;gap:7px;flex-wrap:wrap;margin-bottom:14px}
.tabbar .pf{font-size:11px;font-weight:700;padding:6px 11px;border-radius:8px;cursor:pointer;border:1px solid var(--line);
  background:var(--abyss);color:var(--txt-2);transition:.16s}
.tabbar .pf.on{color:var(--txt);border-color:var(--line-2)}
.card{display:grid;grid-template-columns:auto 1fr auto;gap:14px;align-items:center;padding:14px;border-radius:12px;
  background:var(--abyss);border:1px solid var(--line);border-left-width:3px;margin-bottom:10px;cursor:pointer;
  transition:transform .35s cubic-bezier(.2,.7,.2,1),border-color .2s,opacity .3s}
.card:hover{border-color:var(--line-2);transform:translateX(3px)}
.card.dim{opacity:.32;filter:grayscale(.4)}
.card .pri{width:74px;font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.05em;text-align:center}
.card .ttl{font-size:13.5px;font-weight:600;margin:0 0 4px}
.card .meta{display:flex;gap:8px;flex-wrap:wrap;font-size:10.5px;color:var(--txt-3)}
.card .meta .id{font-family:'JetBrains Mono',monospace;color:var(--cyan)}
.tag{display:inline-flex;align-items:center;gap:5px;font-size:9.5px;font-weight:700;padding:3px 8px;border-radius:6px;
  letter-spacing:.03em;text-transform:uppercase}
.card .right{display:flex;flex-direction:column;align-items:flex-end;gap:6px}
.card .arrow{color:var(--txt-3)}
.tradevec{font-size:10px;color:var(--txt-3);font-family:'JetBrains Mono',monospace}

/* tradespace */
.sliders{display:flex;gap:18px;margin-bottom:6px;flex-wrap:wrap}
.sld{flex:1;min-width:170px}
.sld .sh{display:flex;justify-content:space-between;font-size:11px;color:var(--txt-2);margin-bottom:8px;font-weight:600}
.sld .sh b{color:var(--teal);font-family:'JetBrains Mono',monospace}
input[type=range]{-webkit-appearance:none;width:100%;height:5px;border-radius:5px;background:var(--line);outline:none}
input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:16px;height:16px;border-radius:50%;
  background:var(--teal);cursor:pointer;box-shadow:0 0 0 4px rgba(45,212,191,.18)}
input[type=range]::-moz-range-thumb{width:16px;height:16px;border:none;border-radius:50%;background:var(--teal);cursor:pointer}
.quad-note{font-size:10px;color:var(--txt-3);display:flex;justify-content:space-between;margin-top:4px}

/* drawer */
.scrim{position:fixed;inset:0;background:rgba(4,8,18,.6);backdrop-filter:blur(2px);z-index:40;
  opacity:0;animation:fade .25s forwards}
@keyframes fade{to{opacity:1}}
.drawer{position:fixed;top:0;right:0;bottom:0;width:min(560px,94vw);z-index:50;
  background:linear-gradient(180deg,var(--panel),var(--abyss));border-left:1px solid var(--line);
  box-shadow:-30px 0 60px -20px rgba(0,0,0,.7);display:flex;flex-direction:column;
  transform:translateX(100%);animation:slidein .34s cubic-bezier(.2,.8,.2,1) forwards}
@keyframes slidein{to{transform:translateX(0)}}
.drawer .dh{padding:18px;border-bottom:1px solid var(--line);display:flex;align-items:flex-start;gap:12px}
.drawer .dh h3{margin:0;font-size:15px;font-weight:700}
.drawer .dh .x{margin-left:auto;background:var(--abyss);border:1px solid var(--line);color:var(--txt-2);
  width:32px;height:32px;border-radius:9px;display:grid;place-items:center;cursor:pointer;flex:none}
.drawer .dh .x:hover{color:var(--crit);border-color:var(--crit)}
.drawer .db{padding:18px;overflow-y:auto;flex:1}
.poam{margin-bottom:16px;opacity:0;animation:rise .4s forwards}
.poam:nth-child(1){animation-delay:.05s}.poam:nth-child(2){animation-delay:.12s}
.poam:nth-child(3){animation-delay:.19s}.poam:nth-child(4){animation-delay:.26s}.poam:nth-child(5){animation-delay:.33s}
@keyframes rise{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
.poam .ph{display:flex;align-items:center;justify-content:space-between;margin-bottom:7px}
.poam .pt{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--teal);display:flex;align-items:center;gap:7px}
.poam .cp{background:transparent;border:1px solid var(--line);color:var(--txt-3);font-size:10px;
  padding:3px 9px;border-radius:7px;cursor:pointer;display:flex;align-items:center;gap:5px;font-family:inherit}
.poam .cp:hover{color:var(--teal);border-color:var(--teal)}
.poam .pb{font-size:12.5px;color:var(--txt-2);background:var(--abyss);border:1px solid var(--line);
  border-radius:10px;padding:12px;white-space:pre-wrap}
.ttps{display:flex;gap:6px;flex-wrap:wrap;margin-top:10px}
.ttp{font-family:'JetBrains Mono',monospace;font-size:10px;background:var(--panel-2);border:1px solid var(--line-2);
  color:var(--cyan);padding:3px 8px;border-radius:6px}

/* misc */
.err{background:var(--crit-dim);border:1px solid var(--crit);color:#ffd5de;font-size:12.5px;
  padding:12px 14px;border-radius:11px;margin-top:14px;display:flex;gap:9px}
.err.note{background:var(--med-dim);border-color:var(--med);color:#ffe9bd}
.toast{position:fixed;bottom:24px;left:50%;transform:translateX(-50%);background:var(--panel);
  border:1px solid var(--teal);color:var(--teal);font-size:12.5px;font-weight:600;padding:11px 18px;
  border-radius:999px;z-index:60;box-shadow:var(--shadow);display:flex;gap:8px;align-items:center}
.foot{margin-top:18px;font-size:10.5px;color:var(--txt-3);text-align:center;line-height:1.7}
.rc-tip{background:var(--abyss);border:1px solid var(--line);border-radius:10px;padding:10px 12px;font-size:11px;
  color:var(--txt-2);display:flex;gap:9px;align-items:center;margin-bottom:14px}
.rc-tip b{color:var(--med)}
`;

/* ============================== STATIC DATA ============================== */
const CONNECTIVITY = {
  standalone_no_media: { label: "Standalone System (No Media)", note: "Air-gapped · no peripherals or external media", icon: HardDrive, mult: { Network: 0.08, Adjacent: 0.12, Local: 1.25, Physical: 1.45 } },
  standalone_media:    { label: "Standalone System (With Media)", note: "Air-gapped · permits USB / DVD ingestion", icon: HardDrive, mult: { Network: 0.12, Adjacent: 0.2, Local: 1.3, Physical: 1.6 } },
  standalone_net:      { label: "Standalone Network", note: "Localized net · no external gateways", icon: Network, mult: { Network: 0.3, Adjacent: 1.0, Local: 1.15, Physical: 1.1 } },
  closed_net:          { label: "Closed Network", note: "Enclave · links to other secure nets", icon: Network, mult: { Network: 0.45, Adjacent: 1.1, Local: 1.0, Physical: 0.85 } },
  restricted_net:      { label: "Restricted Network", note: "NIPRNet / VPN · whitelisted egress", icon: Network, mult: { Network: 0.8, Adjacent: 1.0, Local: 0.9, Physical: 0.6 } },
  open_net:            { label: "Open / Connected Network", note: "Internet-facing · public cloud", icon: Network, mult: { Network: 1.0, Adjacent: 0.9, Local: 0.8, Physical: 0.45 } },
};

const RISK_COLOR = { Critical: "var(--crit)", High: "var(--high)", Medium: "var(--med)", Low: "var(--low)", Info: "var(--txt-3)" };
const RISK_DIM = { Critical: "var(--crit-dim)", High: "var(--high-dim)", Medium: "var(--med-dim)", Low: "var(--low-dim)", Info: "var(--line)" };
const PRI_COLOR = { Immediate: "var(--crit)", "Phase 1": "var(--high)", "Phase 2": "var(--med)", Defer: "var(--txt-3)" };
const COST_NUM = { Low: 1, Medium: 2, High: 3 };

const SAMPLE_NESSUS = `<?xml version="1.0"?><NessusClientData_v2><Report name="Scan"><ReportHost name="10.20.4.11">
<ReportItem severity="4" pluginName="MS17-010: Security Update (EternalBlue)"><cve>CVE-2017-0144</cve><cvss3_base_score>9.8</cvss3_base_score><cvss3_vector>CVSS:3.0/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H</cvss3_vector><description>The remote SMBv1 server is affected by remote code execution vulnerabilities.</description><solution>Apply the MS17-010 cumulative update.</solution></ReportItem>
<ReportItem severity="4" pluginName="Apache Log4j RCE (Log4Shell)"><cve>CVE-2021-44228</cve><cvss3_base_score>10.0</cvss3_base_score><cvss3_vector>CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:H</cvss3_vector><description>JNDI lookups in Log4j permit unauthenticated remote code execution.</description><solution>Upgrade Log4j to 2.17.1 or later.</solution></ReportItem>
<ReportItem severity="3" pluginName="Windows Print Spooler Privilege Escalation (PrintNightmare)"><cve>CVE-2021-34527</cve><cvss3_base_score>8.8</cvss3_base_score><cvss3_vector>CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:C/C:H/I:H/A:H</cvss3_vector><description>A local low-priv user can gain SYSTEM via the Print Spooler service.</description><solution>Disable Print Spooler or apply patch.</solution></ReportItem>
<ReportItem severity="2" pluginName="USB Removable Media AutoRun Enabled"><cve>CVE-2010-2568</cve><cvss3_base_score>5.6</cvss3_base_score><cvss3_vector>CVSS:3.0/AV:P/AC:L/PR:N/UI:R/S:U/C:H/I:H/A:H</cvss3_vector><description>AutoRun execution from removable media is enabled, allowing payload delivery via USB.</description><solution>Disable AutoRun/AutoPlay via group policy.</solution></ReportItem>
</ReportHost><ReportHost name="10.20.4.50">
<ReportItem severity="3" pluginName="Apache Tomcat Default Manager Credentials"><cve>CVE-2009-3548</cve><cvss3_base_score>7.5</cvss3_base_score><cvss3_vector>CVSS:3.0/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:L/A:N</cvss3_vector><description>The Tomcat Manager application uses default credentials.</description><solution>Remove or rotate default accounts.</solution></ReportItem>
</ReportHost></Report></NessusClientData_v2>`;

const SAMPLE_CKL = `<?xml version="1.0"?><CHECKLIST><STIGS><iSTIG>
<VULN><STIG_DATA><VULN_ATTRIBUTE>Vuln_Num</VULN_ATTRIBUTE><ATTRIBUTE_DATA>V-220706</ATTRIBUTE_DATA></STIG_DATA><STIG_DATA><VULN_ATTRIBUTE>Rule_ID</VULN_ATTRIBUTE><ATTRIBUTE_DATA>SV-220706r569187_rule</ATTRIBUTE_DATA></STIG_DATA><STIG_DATA><VULN_ATTRIBUTE>Severity</VULN_ATTRIBUTE><ATTRIBUTE_DATA>high</ATTRIBUTE_DATA></STIG_DATA><STIG_DATA><VULN_ATTRIBUTE>Rule_Title</VULN_ATTRIBUTE><ATTRIBUTE_DATA>Local volumes must use NTFS with restrictive ACLs and disk encryption.</ATTRIBUTE_DATA></STIG_DATA><STATUS>Open</STATUS><FINDING_DETAILS>BitLocker not enabled on D: data volume.</FINDING_DETAILS></VULN>
<VULN><STIG_DATA><VULN_ATTRIBUTE>Vuln_Num</VULN_ATTRIBUTE><ATTRIBUTE_DATA>V-220815</ATTRIBUTE_DATA></STIG_DATA><STIG_DATA><VULN_ATTRIBUTE>Rule_ID</VULN_ATTRIBUTE><ATTRIBUTE_DATA>SV-220815r569187_rule</ATTRIBUTE_DATA></STIG_DATA><STIG_DATA><VULN_ATTRIBUTE>Severity</VULN_ATTRIBUTE><ATTRIBUTE_DATA>high</ATTRIBUTE_DATA></STIG_DATA><STIG_DATA><VULN_ATTRIBUTE>Rule_Title</VULN_ATTRIBUTE><ATTRIBUTE_DATA>SMBv1 protocol must be disabled on the system.</ATTRIBUTE_DATA></STIG_DATA><STATUS>Open</STATUS><FINDING_DETAILS>SMB1 feature still installed; correlates with EternalBlue exposure.</FINDING_DETAILS></VULN>
<VULN><STIG_DATA><VULN_ATTRIBUTE>Vuln_Num</VULN_ATTRIBUTE><ATTRIBUTE_DATA>V-220920</ATTRIBUTE_DATA></STIG_DATA><STIG_DATA><VULN_ATTRIBUTE>Rule_ID</VULN_ATTRIBUTE><ATTRIBUTE_DATA>SV-220920r569187_rule</ATTRIBUTE_DATA></STIG_DATA><STIG_DATA><VULN_ATTRIBUTE>Severity</VULN_ATTRIBUTE><ATTRIBUTE_DATA>medium</ATTRIBUTE_DATA></STIG_DATA><STIG_DATA><VULN_ATTRIBUTE>Rule_Title</VULN_ATTRIBUTE><ATTRIBUTE_DATA>Removable media write access must be restricted via policy.</ATTRIBUTE_DATA></STIG_DATA><STATUS>Open</STATUS><FINDING_DETAILS>USB mass storage write not blocked.</FINDING_DETAILS></VULN>
<VULN><STIG_DATA><VULN_ATTRIBUTE>Vuln_Num</VULN_ATTRIBUTE><ATTRIBUTE_DATA>V-221110</ATTRIBUTE_DATA></STIG_DATA><STIG_DATA><VULN_ATTRIBUTE>Rule_ID</VULN_ATTRIBUTE><ATTRIBUTE_DATA>SV-221110r569187_rule</ATTRIBUTE_DATA></STIG_DATA><STIG_DATA><VULN_ATTRIBUTE>Severity</VULN_ATTRIBUTE><ATTRIBUTE_DATA>medium</ATTRIBUTE_DATA></STIG_DATA><STIG_DATA><VULN_ATTRIBUTE>Rule_Title</VULN_ATTRIBUTE><ATTRIBUTE_DATA>Application allowlisting (WDAC/AppLocker) must be enforced.</ATTRIBUTE_DATA></STIG_DATA><STATUS>Open</STATUS><FINDING_DETAILS>No allowlisting policy deployed.</FINDING_DETAILS></VULN>
</iSTIG></STIGS></CHECKLIST>`;

const SYSTEM_PROMPT = `You are VulneraSight AI, an expert Cybersecurity AI Engine specializing in Risk Assessment, Threat Modeling, Vulnerability Remediation, and MITRE ATT&CK mapping. You ingest correlated Nessus vulnerability findings and STIG (.ckl) checklist findings and produce threat-informed analysis for a specific operational connectivity context.

Connectivity contexts and their meaning:
- Standalone (No Media): air-gapped, no peripherals — remote/network vectors are negligible; local & physical vectors dominate (insider threat).
- Standalone (With Media): air-gapped but USB/DVD allowed — removable-media, AutoRun and supply-chain vectors are heightened.
- Standalone / Closed Network: enclaved — focus on lateral movement, internal trust relationships, credential access.
- Restricted / Open Network: externally reachable — remote code execution and public-facing exploitation dominate (outsider / near-peer APT).

For the EXECUTIVE SUMMARY, judge severity THROUGH the connectivity lens: an AV:N RCE on a Standalone No-Media system is materially de-rated, while a local privilege-escalation or USB AutoRun flaw is elevated. Map weaknesses to concrete MITRE ATT&CK TTP IDs. Write in an objective, analytical tone suitable for a CISO or Authorizing Official. Never recommend internet patch downloads as an immediate fix for standalone systems; provide air-gap-appropriate compensating controls instead.

Respond with ONLY valid JSON, no markdown fences, no preamble, matching exactly this schema:
{
 "executiveSummary": {
   "overallRiskRating": "Low|Medium|High|Critical",
   "primaryThreatProfile": "Insider|Near-Peer|Outsider",
   "threatJustification": "2-3 sentences citing specific MITRE ATT&CK TTP IDs (e.g. T1190, T1210, T1091).",
   "connectivityImpactStatement": "2-3 sentences on how this connectivity dampens or amplifies the raw vulnerabilities."
 },
 "findings": [
   {
     "id": "matches the provided finding id",
     "title": "concise human title",
     "identifier": "CVE id and/or STIG Vuln id",
     "source": "Nessus|CKL|Correlated",
     "attackVector": "Network|Adjacent|Local|Physical",
     "baseCvss": 0.0,
     "complexity": "Low|Medium|High",
     "cost": "Low|Medium|High",
     "mitreTtps": ["T####"],
     "poam": {
       "compensatingControl": "what to do right now to lower risk WITHOUT patching, appropriate to the connectivity type",
       "impactLanguage": "professional POA&M text describing operational and security impact",
       "mitigationLanguage": "professional POA&M text describing short-term technical mitigation steps",
       "milestoneLanguage": "phased milestone schedule with day targets, e.g. Milestone 1 (30 days)..., Milestone 2 (60 days)..., Milestone 3 (120 days)..."
     }
   }
 ]
}
Include every finding provided. Set attackVector from the CVSS vector when available (AV:N=Network, AV:A=Adjacent, AV:L=Local, AV:P=Physical). Keep each POA&M field under ~55 words.`;

/* ============================== PARSING ============================== */
function parseNessus(xml) {
  const out = [];
  try {
    const doc = new DOMParser().parseFromString(xml, "text/xml");
    doc.querySelectorAll("ReportHost").forEach((host) => {
      const asset = host.getAttribute("name") || "unknown";
      host.querySelectorAll("ReportItem").forEach((it, i) => {
        const cve = it.querySelector("cve")?.textContent || "";
        const score = parseFloat(it.querySelector("cvss3_base_score")?.textContent || "0");
        const vec = it.querySelector("cvss3_vector")?.textContent || "";
        out.push({
          id: `N-${asset}-${i}`, src: "Nessus", asset,
          title: it.getAttribute("pluginName") || "Nessus Finding",
          cve, cvss: score, vector: vec,
          desc: it.querySelector("description")?.textContent?.slice(0, 240) || "",
          severity: parseInt(it.getAttribute("severity") || "0", 10),
        });
      });
    });
  } catch (e) { /* malformed */ }
  return out;
}
function ckText(vuln, attr) {
  let v = "";
  vuln.querySelectorAll("STIG_DATA").forEach((sd) => {
    if (sd.querySelector("VULN_ATTRIBUTE")?.textContent === attr)
      v = sd.querySelector("ATTRIBUTE_DATA")?.textContent || "";
  });
  return v;
}
function parseCkl(xml) {
  const out = [];
  try {
    const doc = new DOMParser().parseFromString(xml, "text/xml");
    doc.querySelectorAll("VULN").forEach((v, i) => {
      const status = v.querySelector("STATUS")?.textContent || "";
      if (!/open/i.test(status)) return;
      out.push({
        id: `C-${i}`, src: "CKL",
        vulnNum: ckText(v, "Vuln_Num"),
        ruleId: ckText(v, "Rule_ID"),
        severity: ckText(v, "Severity"),
        title: ckText(v, "Rule_Title") || "STIG Finding",
        details: v.querySelector("FINDING_DETAILS")?.textContent?.slice(0, 200) || "",
      });
    });
  } catch (e) { /* malformed */ }
  return out;
}
function maskText(s) {
  return String(s)
    .replace(/\b(\d{1,3}\.){3}\d{1,3}\b/g, "ASSET-REDACTED")
    .replace(/\b[a-z0-9-]+\.(local|corp|gov|mil|net|internal)\b/gi, "HOST-REDACTED");
}

/* Decide whether an uploaded artifact is a Nessus scan or a STIG checklist.
   Extension is authoritative; content sniffing only resolves ambiguous .xml
   (and uses distinctive ROOT markers, not loose substrings — a real .nessus
   file legitimately contains tags like <vuln_publication_date>). */
function classifyArtifact(name, text) {
  const lower = (name || "").toLowerCase();
  if (lower.endsWith(".ckl") || lower.endsWith(".cklb")) return "ckl";
  if (lower.endsWith(".nessus")) return "nessus";

  const isCkl = /<CHECKLIST[\s>]|<STIG_INFO[\s>]|<iSTIG[\s>]|<STIG_DATA[\s>]/i.test(text);
  const isNessus = /NessusClientData|<ReportHost[\s>]|<ReportItem[\s>]|<policyName[\s>]/i.test(text);
  if (isCkl && !isNessus) return "ckl";
  if (isNessus && !isCkl) return "nessus";
  if (/<CHECKLIST[\s>]/i.test(text)) return "ckl";          // checklist root wins ties
  if (/NessusClientData|<Report[\s>]/i.test(text)) return "nessus";
  return isCkl ? "ckl" : "nessus";
}

/* Close a truncated JSON string by completing open strings/brackets, so a
   response cut off mid-object can still be salvaged. */
function closeJson(s) {
  const stack = [];
  let inStr = false, esc = false;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (inStr) {
      if (esc) esc = false;
      else if (c === "\\") esc = true;
      else if (c === '"') inStr = false;
      continue;
    }
    if (c === '"') inStr = true;
    else if (c === "{") stack.push("}");
    else if (c === "[") stack.push("]");
    else if (c === "}" || c === "]") stack.pop();
  }
  let out = s;
  if (inStr) out += '"';
  // drop trailing commas / dangling keys with no value
  out = out.replace(/[\s,]+$/, "");
  out = out.replace(/,?\s*"[^"]*"\s*:\s*$/, "").replace(/[\s,]+$/, "");
  for (let i = stack.length - 1; i >= 0; i--) out += stack[i];
  return out;
}

/* Pull a JSON object out of a model response, repairing truncation if needed.
   Returns { data, truncated } or null. */
function extractJson(raw) {
  let s = String(raw || "").replace(/```json/gi, "").replace(/```/g, "").trim();
  const start = s.indexOf("{");
  if (start === -1) return null;
  s = s.slice(start);
  const end = s.lastIndexOf("}");
  if (end !== -1) {
    try { return { data: JSON.parse(s.slice(0, end + 1)), truncated: false }; } catch (e) { /* fall through */ }
  }
  try { return { data: JSON.parse(closeJson(s)), truncated: true }; } catch (e) { /* fall through */ }
  return null;
}

/* ============================== ANALYSIS ENGINE ============================== */
function riskFromScore(s) {
  if (s >= 9) return "Critical"; if (s >= 7) return "High";
  if (s >= 4) return "Medium"; if (s > 0) return "Low"; return "Info";
}
function priorityFor(risk, complexity, budget) {
  const r = { Critical: 4, High: 3, Medium: 2, Low: 1, Info: 0 }[risk];
  const cx = { Low: 0, Medium: 1, High: 2 }[complexity] ?? 1;
  let tier;
  if (r >= 4) tier = cx === 0 ? "Immediate" : "Phase 1";
  else if (r === 3) tier = cx === 0 ? "Immediate" : "Phase 1";
  else if (r === 2) tier = cx <= 1 ? "Phase 1" : "Phase 2";
  else if (r === 1) tier = "Phase 2";
  else tier = "Defer";
  // budget pressure: scarce budget defers expensive, non-critical items
  if (budget === "Low" && complexity === "High" && r < 4) {
    tier = tier === "Phase 1" ? "Phase 2" : tier === "Phase 2" ? "Defer" : tier;
  }
  return tier;
}
function buildModel(findings, connKey, budget) {
  const mult = CONNECTIVITY[connKey].mult;
  const enriched = findings.map((f) => {
    const m = mult[f.attackVector] ?? 0.6;
    const realScore = Math.max(0, Math.min(10, (f.baseCvss || 0) * m));
    const realRisk = riskFromScore(realScore);
    const priority = priorityFor(realRisk, f.complexity, budget);
    const effort = { Low: 18, Medium: 50, High: 82 }[f.complexity] ?? 50;
    const jitter = (parseInt(f.id.replace(/\D/g, "").slice(-2) || "0", 10) % 16) - 8;
    return {
      ...f, realScore: +realScore.toFixed(1), realRisk, priority,
      effort: Math.max(6, Math.min(94, effort + jitter)),
      impact: Math.round(realScore * 10), costNum: COST_NUM[f.cost] ?? 2,
    };
  });

  // threat dimensions (relative shape) + headline profiles (absolute)
  const n = enriched.length || 1;
  let remote = 0, lateral = 0, priv = 0, media = 0, insider = 0, exposure = 0;
  enriched.forEach((f) => {
    const w = f.realScore, av = f.attackVector;
    if (av === "Network") { remote += w; exposure += w * 0.9; lateral += w * 0.3; }
    if (av === "Adjacent") { lateral += w; remote += w * 0.3; }
    if (av === "Local") { priv += w; insider += w * 0.7; lateral += w * 0.4; }
    if (av === "Physical") { media += w; insider += w * 0.9; }
  });
  const mediaBoost = connKey === "standalone_media" ? 1.35 : 1;
  media *= mediaBoost;
  const dims = [
    { axis: "Remote Exploit", v: remote }, { axis: "Public Exposure", v: exposure },
    { axis: "Lateral Move", v: lateral }, { axis: "Priv Escalation", v: priv },
    { axis: "Removable Media", v: media }, { axis: "Insider Misuse", v: insider },
  ];
  const maxDim = Math.max(...dims.map((d) => d.v), 1);
  const radar = dims.map((d) => ({ axis: d.axis, value: Math.round((d.v / maxDim) * 100) }));

  const norm = (raw, k = 9) => Math.max(4, Math.min(100, Math.round((raw / (n * k)) * 100)));
  const profiles = {
    Insider: norm(insider + media * 0.6),
    "Near-Peer": norm(lateral + remote * 0.5 + enriched.filter((f) => f.complexity === "High").length * 6),
    Outsider: norm(remote + exposure * 0.6),
  };
  return { enriched, radar, profiles };
}

/* ============================== SMALL UI BITS ============================== */
function RiskBadge({ level }) {
  return <span className="tag" style={{ background: RISK_DIM[level], color: RISK_COLOR[level], border: `1px solid ${RISK_COLOR[level]}` }}>{level}</span>;
}
function RadialGauge({ value, label }) {
  const r = 52, c = 2 * Math.PI * r;
  const pct = { Low: 0.3, Medium: 0.55, High: 0.78, Critical: 1 }[value] ?? 0.5;
  const col = RISK_COLOR[value] || "var(--teal)";
  return (
    <div className="gauge">
      <svg width="128" height="128">
        <circle cx="64" cy="64" r={r} fill="none" stroke="var(--line)" strokeWidth="9" />
        <circle cx="64" cy="64" r={r} fill="none" stroke={col} strokeWidth="9" strokeLinecap="round"
          strokeDasharray={c} strokeDashoffset={c * (1 - pct)} style={{ transition: "stroke-dashoffset .9s ease, stroke .4s" }} />
      </svg>
      <div style={{ marginTop: -82, textAlign: "center" }}>
        <div style={{ fontSize: 9, color: "var(--txt-3)", letterSpacing: ".12em", textTransform: "uppercase" }}>{label}</div>
        <div className="num" style={{ color: col, marginTop: 4 }}>{value}</div>
      </div>
      <div style={{ height: 30 }} />
    </div>
  );
}

/* ============================== MAIN ============================== */
export default function VulneraSight() {
  const [files, setFiles] = useState({ nessus: null, ckl: null });
  const [conn, setConn] = useState("restricted_net");
  const [budget, setBudget] = useState("Medium");
  const [capacity, setCapacity] = useState("Standard");
  const [mask, setMask] = useState(true);
  const [hot, setHot] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [ai, setAi] = useState(null);          // raw AI output
  const [analyzedConn, setAnalyzedConn] = useState(null);
  const [pfilter, setPfilter] = useState("All");
  const [maxEffort, setMaxEffort] = useState(100);
  const [maxCost, setMaxCost] = useState(3);
  const [drawer, setDrawer] = useState(null);
  const [copied, setCopied] = useState("");
  const inputRef = useRef(null);

  const onFiles = useCallback((list) => {
    setError("");
    Array.from(list).forEach((f) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const text = e.target.result;
        const kind = classifyArtifact(f.name, text);
        setFiles((prev) => ({ ...prev, [kind]: { name: f.name, text } }));
      };
      reader.readAsText(f);
    });
  }, []);

  const loadDemo = () => {
    setFiles({ nessus: { name: "scan_results.nessus", text: SAMPLE_NESSUS }, ckl: { name: "system_checklist.ckl", text: SAMPLE_CKL } });
    setError("");
  };

  const rawFindings = useMemo(() => {
    const ness = files.nessus ? parseNessus(files.nessus.text) : [];
    const ckl = files.ckl ? parseCkl(files.ckl.text) : [];
    return { ness, ckl, total: ness.length + ckl.length };
  }, [files]);

  async function runAnalysis() {
    if (!rawFindings.total) { setError("Load a .nessus and/or .ckl file (or the demo dataset) before running analysis."); return; }
    setBusy(true); setError(""); setAi(null);

    const m = (s) => (mask ? maskText(s) : s);
    const sevRank = { high: 3, medium: 2, low: 1 };
    const topNess = [...rawFindings.ness].sort((a, b) => (b.cvss || 0) - (a.cvss || 0)).slice(0, 9);
    const topCkl = [...rawFindings.ckl]
      .sort((a, b) => (sevRank[(b.severity || "").toLowerCase()] || 0) - (sevRank[(a.severity || "").toLowerCase()] || 0))
      .slice(0, 7);
    const payload = {
      connectivity: CONNECTIVITY[conn].label,
      budget, remediationCapacity: capacity,
      nessus: topNess.map((f) => ({
        id: f.id, asset: m(f.asset), title: f.title, cve: f.cve, cvss: f.cvss, vector: f.vector, summary: m(f.desc),
      })),
      ckl: topCkl.map((f) => ({
        id: f.id, vulnNum: f.vulnNum, ruleId: f.ruleId, severity: f.severity, title: f.title, details: m(f.details),
      })),
    };
    const sentCount = payload.nessus.length + payload.ckl.length;

    try {
      const resp = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 8000,
          system: SYSTEM_PROMPT,
          messages: [{
            role: "user",
            content: `Operational context: connectivity = ${payload.connectivity}; cybersecurity budget = ${budget}; remediation capacity = ${capacity}.\n\nCorrelate and analyze these findings (treat overlapping Nessus + STIG items as a single correlated finding where appropriate). Return JSON only.\n\nFINDINGS:\n${JSON.stringify({ nessus: payload.nessus, ckl: payload.ckl })}`,
          }],
        }),
      });
      const data = await resp.json();

      if (!resp.ok || data.type === "error" || data.error) {
        const msg = data?.error?.message || `Request failed (HTTP ${resp.status}).`;
        if (/overload|rate|429|529/i.test(msg + resp.status)) throw new Error("The analysis service is busy right now. Wait a few seconds and run it again.");
        throw new Error(msg);
      }

      const blocks = Array.isArray(data.content) ? data.content : [];
      const text = blocks.filter((b) => b.type === "text").map((b) => b.text).join("\n");
      if (!text.trim()) throw new Error("The analysis service returned an empty response. Please run it again.");

      const res = extractJson(text);
      if (!res || !res.data || !Array.isArray(res.data.findings) || res.data.findings.length === 0) {
        throw new Error("The response wasn't valid structured data. Run it again — it usually succeeds on retry.");
      }

      // keep only findings that have enough to render
      res.data.findings = res.data.findings.filter((f) => f && (f.title || f.identifier));
      setAi(res.data);
      setAnalyzedConn(conn);
      setPfilter("All");

      const truncated = res.truncated || data.stop_reason === "max_tokens";
      const dropped = rawFindings.total - sentCount;
      const notes = [];
      if (dropped > 0) notes.push(`Analyzed the ${sentCount} highest-severity findings; ${dropped} lower-severity item${dropped > 1 ? "s were" : " was"} not included.`);
      if (truncated) notes.push("The response was long and may have been cut short — the last finding's text could be incomplete.");
      setError(notes.length ? "NOTE:" + notes.join(" ") : "");
    } catch (e) {
      setError(e?.message || "The analysis engine hit an unexpected error. Please run it again.");
    } finally {
      setBusy(false);
    }
  }

  const model = useMemo(() => ai ? buildModel(ai.findings, conn, budget) : null, [ai, conn, budget]);

  const visible = useMemo(() => {
    if (!model) return [];
    const order = { Immediate: 0, "Phase 1": 1, "Phase 2": 2, Defer: 3 };
    return [...model.enriched]
      .filter((f) => pfilter === "All" || f.priority === pfilter)
      .sort((a, b) => (order[a.priority] - order[b.priority]) || (b.realScore - a.realScore));
  }, [model, pfilter]);

  const copy = (txt, key) => {
    navigator.clipboard?.writeText(txt);
    setCopied(key); setTimeout(() => setCopied(""), 1400);
  };

  function exportCsv() {
    if (!model) return;
    const rows = [["Priority", "Title", "Identifier", "Real Risk", "Raw CVSS", "Attack Vector", "Connectivity", "POA&M Impact", "POA&M Mitigation", "Milestones"]];
    model.enriched.forEach((f) => rows.push([
      f.priority, f.title, f.identifier, f.realRisk, f.baseCvss, f.attackVector,
      CONNECTIVITY[conn].label, f.poam?.impactLanguage || "", f.poam?.mitigationLanguage || "", f.poam?.milestoneLanguage || "",
    ]));
    const csv = rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(",")).join("\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    const a = document.createElement("a"); a.href = url; a.download = "VulneraSight_POAM.csv"; a.click();
    URL.revokeObjectURL(url);
  }

  const Conn = CONNECTIVITY[conn].icon;
  const ctxChanged = ai && analyzedConn && analyzedConn !== conn;
  const leadProfile = model ? Object.entries(model.profiles).sort((a, b) => b[1] - a[1])[0][0] : null;

  return (
    <div className="vs-root">
      <style>{STYLES}</style>
      <div className="vs-wrap">
        {/* header */}
        <div className="vs-top">
          <div className="vs-mark"><Shield size={22} strokeWidth={2.2} /></div>
          <div>
            <div className="vs-brand">Vulnera<span>Sight</span> AI</div>
            <div className="vs-sub">Threat-Informed Risk Correlation Engine</div>
          </div>
          <div className="vs-status"><span className="dot" /> Engine ready</div>
        </div>

        <div className="grid">
          {/* ---------- LEFT: inputs ---------- */}
          <div>
            <div className="panel pad" style={{ marginBottom: 18 }}>
              <div className="eyebrow"><Upload size={13} className="ic" /> Ingestion</div>
              <div
                className={`dz ${hot ? "hot" : ""}`}
                onClick={() => inputRef.current?.click()}
                onDragOver={(e) => { e.preventDefault(); setHot(true); }}
                onDragLeave={() => setHot(false)}
                onDrop={(e) => { e.preventDefault(); setHot(false); onFiles(e.dataTransfer.files); }}
              >
                <div className="up"><Upload size={18} /></div>
                <h4>Drop scan artifacts</h4>
                <p>.nessus &amp; .ckl — multi-file supported</p>
                {busy && <div className="shimmer"><i /></div>}
                <input ref={inputRef} type="file" multiple accept=".nessus,.ckl,.xml" style={{ display: "none" }}
                  onChange={(e) => onFiles(e.target.files)} />
              </div>
              <div className="chips">
                <div className={`chip ${files.nessus ? "ok" : ""}`}>
                  <FileCheck2 size={14} /><span><span className="lab">NESSUS</span>
                    <span className="fn">{files.nessus ? files.nessus.name : "awaiting"}</span></span>
                </div>
                <div className={`chip ${files.ckl ? "ok" : ""}`}>
                  <FileWarning size={14} /><span><span className="lab">STIG CKL</span>
                    <span className="fn">{files.ckl ? files.ckl.name : "awaiting"}</span></span>
                </div>
              </div>
              {rawFindings.total > 0 &&
                <div className="connote" style={{ marginTop: 11 }}>
                  <Activity size={12} /> Parsed <b style={{ color: "var(--teal)", margin: "0 3px" }}>{rawFindings.total}</b> findings
                  ({rawFindings.ness.length} Nessus · {rawFindings.ckl.length} open STIG)
                </div>}
              <button className="btn ghost" style={{ marginTop: 12 }} onClick={loadDemo}>
                <Layers size={13} /> Load demo dataset
              </button>
            </div>

            <div className="panel pad">
              <div className="eyebrow"><SlidersHorizontal size={13} className="ic" /> Operational Context</div>

              <div className="ctrl">
                <label>Connectivity Profile</label>
                <select className="sel" value={conn} onChange={(e) => setConn(e.target.value)}>
                  {Object.entries(CONNECTIVITY).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
                </select>
                <div className="connote"><Conn size={12} /> {CONNECTIVITY[conn].note}</div>
              </div>

              <div className="ctrl">
                <label>Cybersecurity Budget</label>
                <div className="seg">
                  {["Low", "Medium", "High"].map((b) =>
                    <button key={b} className={budget === b ? "on" : ""} onClick={() => setBudget(b)}>{b}</button>)}
                </div>
              </div>

              <div className="ctrl">
                <label>Remediation Capacity</label>
                <div className="seg">
                  {["Urgent", "Standard", "Constrained"].map((c) =>
                    <button key={c} className={capacity === c ? "on" : ""} onClick={() => setCapacity(c)}
                      style={{ fontSize: 11 }}>{c}</button>)}
                </div>
              </div>

              <div className="ctrl">
                <div className="toggle">
                  <div>
                    <div className="t" style={{ display: "flex", alignItems: "center", gap: 7 }}>
                      {mask ? <EyeOff size={13} /> : <Eye size={13} />} Data masking</div>
                    <div className="d">Redact IPs &amp; hostnames before AI call</div>
                  </div>
                  <div className={`sw ${mask ? "on" : ""}`} onClick={() => setMask(!mask)} role="switch" aria-checked={mask}><i /></div>
                </div>
              </div>

              <button className="btn primary" disabled={busy || !rawFindings.total} onClick={runAnalysis}>
                {busy ? <><Loader2 size={16} className="spin" style={{ animation: "spin 1s linear infinite" }} /> Correlating…</>
                  : <><Crosshair size={16} /> {ai ? "Re-run analysis" : "Run threat analysis"}</>}
              </button>
              {error && (error.startsWith("NOTE:")
                ? <div className="err note"><Activity size={15} style={{ flex: "none", marginTop: 1 }} /> {error.slice(5)}</div>
                : <div className="err"><AlertOctagon size={15} style={{ flex: "none", marginTop: 1 }} /> {error}</div>)}
            </div>
          </div>

          {/* ---------- RIGHT: results ---------- */}
          <div>
            {!ai && !busy &&
              <div className="panel hero">
                <div className="ring"><RadarIcon size={40} color="var(--teal)" /></div>
                <h2>Threat posture, in context</h2>
                <p>VulneraSight correlates raw Nessus and STIG findings, then re-weights every weakness through your system's real connectivity — so an air-gapped box isn't judged like an internet-facing one.</p>
                <div className="steps">
                  <div className="step"><b>01</b> Ingest artifacts</div>
                  <div className="step"><b>02</b> Set connectivity &amp; budget</div>
                  <div className="step"><b>03</b> Generate roadmap &amp; POA&amp;M</div>
                </div>
              </div>}

            {busy &&
              <div className="panel hero">
                <Loader2 size={42} color="var(--teal)" style={{ animation: "spin 1s linear infinite", marginBottom: 18 }} />
                <h2>Modeling threat posture…</h2>
                <p>Parsing CVSS vectors, correlating STIG findings, mapping MITRE ATT&CK TTPs and drafting POA&amp;M language for a {CONNECTIVITY[conn].label} context.</p>
              </div>}

            {ai && model && <>
              {ctxChanged &&
                <div className="rc-tip">
                  <RotateCcw size={14} style={{ color: "var(--med)", flex: "none" }} />
                  Risk scores and posture below recompute live for <b style={{ color: "var(--teal)" }}>{CONNECTIVITY[conn].label}</b>. The written summary &amp; POA&amp;M text still reflect the analyzed profile — re-run to refresh the narrative.
                </div>}

              {/* SECTION 1 */}
              <div className="panel pad" style={{ marginBottom: 18 }}>
                <div className="eyebrow"><Shield size={13} className="ic" /> §1 · Executive Summary &amp; Threat Posture</div>
                <div className="exec">
                  <RadialGauge value={ai.executiveSummary.overallRiskRating} label="Overall Risk" />
                  <div className="exec-body">
                    <div className="kv">
                      {Object.entries(model.profiles).map(([k, v]) =>
                        <div key={k} className={`profile-card ${k === leadProfile ? "lead" : ""}`}>
                          <div className="pl">
                            {k === "Insider" ? <Cpu size={11} /> : k === "Outsider" ? <Network size={11} /> : <Activity size={11} />} {k}
                          </div>
                          <div className="pv" style={{ color: k === leadProfile ? "var(--teal)" : "var(--txt)" }}>{v}</div>
                          <div className="bar"><i style={{ width: `${v}%`, background: k === leadProfile ? "var(--teal)" : "var(--line-2)" }} /></div>
                        </div>)}
                    </div>
                    <p><b>Primary susceptibility — {ai.executiveSummary.primaryThreatProfile}.</b> {ai.executiveSummary.threatJustification}</p>
                    <p><b>Connectivity impact.</b> {ai.executiveSummary.connectivityImpactStatement}</p>
                  </div>
                </div>
              </div>

              {/* Threat matrix radar */}
              <div className="panel pad" style={{ marginBottom: 18 }}>
                <div className="eyebrow"><RadarIcon size={13} className="ic" /> Threat Posture Matrix · {CONNECTIVITY[conn].label}</div>
                <div className="split">
                  <div style={{ height: 290 }}>
                    <ResponsiveContainer>
                      <RadarChart data={model.radar} outerRadius="74%">
                        <PolarGrid stroke="var(--line)" />
                        <PolarAngleAxis dataKey="axis" tick={{ fill: "var(--txt-2)", fontSize: 10.5 }} />
                        <PolarRadiusAxis domain={[0, 100]} tick={false} axisLine={false} />
                        <Radar dataKey="value" stroke="var(--teal)" fill="var(--teal)" fillOpacity={0.28} strokeWidth={2}
                          isAnimationActive animationDuration={650} />
                      </RadarChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="dims">
                    {model.radar.map((d) =>
                      <div key={d.axis}>
                        <div className="dimrow"><span className="dn">{d.axis}</span><span className="dv">{d.value}</span></div>
                        <div className="dimrow"><div className="track"><i style={{ width: `${d.value}%` }} /></div></div>
                      </div>)}
                  </div>
                </div>
              </div>

              {/* SECTION 2 — roadmap */}
              <div className="panel pad" style={{ marginBottom: 18 }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 10 }}>
                  <div className="eyebrow" style={{ margin: 0 }}><Layers size={13} className="ic" /> §2 · Prioritized Remediation Roadmap</div>
                  <button className="btn ghost" style={{ width: "auto", padding: "8px 13px" }} onClick={exportCsv}>
                    <Download size={13} /> Export POA&amp;M (.csv)
                  </button>
                </div>
                <div className="tabbar" style={{ marginTop: 13 }}>
                  {["All", "Immediate", "Phase 1", "Phase 2", "Defer"].map((p) =>
                    <div key={p} className={`pf ${pfilter === p ? "on" : ""}`} onClick={() => setPfilter(p)}
                      style={pfilter === p && p !== "All" ? { color: PRI_COLOR[p], borderColor: PRI_COLOR[p] } : {}}>
                      {p}{p !== "All" && <span style={{ opacity: .6, marginLeft: 5 }}>
                        {model.enriched.filter((f) => f.priority === p).length}</span>}
                    </div>)}
                </div>
                {visible.map((f) => {
                  const dim = f.effort > maxEffort || f.costNum > maxCost;
                  return (
                    <div key={f.id} className={`card ${dim ? "dim" : ""}`}
                      style={{ borderLeftColor: PRI_COLOR[f.priority] }} onClick={() => setDrawer(f)}>
                      <div className="pri" style={{ color: PRI_COLOR[f.priority] }}>{f.priority}</div>
                      <div>
                        <div className="ttl">{f.title}</div>
                        <div className="meta">
                          <span className="id">{f.identifier}</span>
                          <span>· {f.source}</span>
                          <span>· {f.attackVector}</span>
                          <span className="tradevec">· {f.cost} cost / {f.complexity} effort</span>
                        </div>
                      </div>
                      <div className="right">
                        <RiskBadge level={f.realRisk} />
                        <span className="tradevec">CVSS {f.baseCvss} → {f.realScore}</span>
                        <ChevronRight size={15} className="arrow" />
                      </div>
                    </div>
                  );
                })}
                {!visible.length && <p style={{ color: "var(--txt-3)", fontSize: 13, textAlign: "center", padding: 20 }}>No findings in this tier.</p>}
              </div>

              {/* SECTION 3 — tradespace */}
              <div className="panel pad">
                <div className="eyebrow"><Crosshair size={13} className="ic" /> §3 · Tradespace Planner — Impact vs Effort</div>
                <div className="sliders">
                  <div className="sld">
                    <div className="sh"><span>Engineering effort ceiling</span><b>{maxEffort === 100 ? "no limit" : `≤ ${maxEffort}`}</b></div>
                    <input type="range" min="20" max="100" step="2" value={maxEffort} onChange={(e) => setMaxEffort(+e.target.value)} />
                  </div>
                  <div className="sld">
                    <div className="sh"><span>Budget ceiling</span><b>{["", "Low", "≤ Medium", "no limit"][maxCost]}</b></div>
                    <input type="range" min="1" max="3" step="1" value={maxCost} onChange={(e) => setMaxCost(+e.target.value)} />
                  </div>
                </div>
                <div style={{ height: 320 }}>
                  <ResponsiveContainer>
                    <ScatterChart margin={{ top: 12, right: 18, bottom: 28, left: 6 }}>
                      <CartesianGrid stroke="var(--line)" strokeDasharray="3 3" />
                      <ReferenceArea x1={0} x2={40} y1={60} y2={100} fill="var(--teal)" fillOpacity={0.06} />
                      <XAxis type="number" dataKey="effort" domain={[0, 100]} name="Effort" tick={{ fill: "var(--txt-3)", fontSize: 10 }}
                        label={{ value: "Engineering Effort →", position: "bottom", fill: "var(--txt-3)", fontSize: 11 }} />
                      <YAxis type="number" dataKey="impact" domain={[0, 100]} name="Impact" tick={{ fill: "var(--txt-3)", fontSize: 10 }}
                        label={{ value: "Risk Impact →", angle: -90, position: "insideLeft", fill: "var(--txt-3)", fontSize: 11 }} />
                      <ZAxis type="number" dataKey="bubble" range={[80, 420]} />
                      <Tooltip cursor={{ strokeDasharray: "3 3", stroke: "var(--teal)" }}
                        contentStyle={{ background: "var(--panel-2)", border: "1px solid var(--line-2)", borderRadius: 10, fontSize: 12 }}
                        labelStyle={{ color: "var(--txt)" }}
                        formatter={(val, name) => [val, name]}
                        content={({ payload }) => payload && payload[0] ? (
                          <div style={{ background: "var(--panel-2)", border: "1px solid var(--line-2)", borderRadius: 10, padding: "9px 12px", fontSize: 12 }}>
                            <div style={{ fontWeight: 700, marginBottom: 3 }}>{payload[0].payload.title}</div>
                            <div style={{ color: "var(--txt-3)", fontSize: 11 }}>
                              {payload[0].payload.priority} · impact {payload[0].payload.impact} · effort {payload[0].payload.effort}
                            </div>
                          </div>) : null} />
                      <Scatter
                        data={model.enriched.filter((f) => f.effort <= maxEffort && f.costNum <= maxCost)
                          .map((f) => ({ ...f, bubble: f.costNum }))}
                        isAnimationActive animationDuration={500}
                        onClick={(p) => p && setDrawer(p)} cursor="pointer">
                        {model.enriched.filter((f) => f.effort <= maxEffort && f.costNum <= maxCost).map((f) =>
                          <Cell key={f.id} fill={RISK_COLOR[f.realRisk]} fillOpacity={0.78}
                            stroke={RISK_COLOR[f.realRisk]} strokeWidth={1} />)}
                      </Scatter>
                    </ScatterChart>
                  </ResponsiveContainer>
                </div>
                <div className="quad-note"><span>Top-left band = high impact, low effort → quick wins</span>
                  <span>Bubble size = cost · color = real risk</span></div>
              </div>

              <div className="foot">
                VulneraSight AI · contextual analysis for {CONNECTIVITY[conn].label} · budget {budget} · {capacity} capacity{mask ? " · data masking on" : ""}<br />
                Adjusted risk scoring and posture are deterministic; threat narrative and POA&amp;M language are AI-generated and should be analyst-reviewed before submission.
              </div>
            </>}
          </div>
        </div>
      </div>

      {/* DRAWER */}
      {drawer &&
        <>
          <div className="scrim" onClick={() => setDrawer(null)} />
          <aside className="drawer">
            <div className="dh">
              <div style={{ marginTop: 2 }}><RiskBadge level={drawer.realRisk} /></div>
              <div>
                <h3>{drawer.title}</h3>
                <div className="mono" style={{ fontSize: 11, color: "var(--cyan)", marginTop: 4 }}>{drawer.identifier}</div>
                <div style={{ fontSize: 11, color: "var(--txt-3)", marginTop: 3 }}>
                  {drawer.priority} · {drawer.attackVector} vector · CVSS {drawer.baseCvss} → contextual {drawer.realScore}
                </div>
                {drawer.mitreTtps?.length > 0 &&
                  <div className="ttps">{drawer.mitreTtps.map((t) => <span key={t} className="ttp">{t}</span>)}</div>}
              </div>
              <button className="x" onClick={() => setDrawer(null)}><X size={16} /></button>
            </div>
            <div className="db">
              {[
                ["Compensating Control", drawer.poam?.compensatingControl, "cc"],
                ["POA&M — Impact", drawer.poam?.impactLanguage, "im"],
                ["POA&M — Mitigation", drawer.poam?.mitigationLanguage, "mi"],
                ["POA&M — Milestones", drawer.poam?.milestoneLanguage, "ms"],
              ].map(([label, body, key]) =>
                <div className="poam" key={key}>
                  <div className="ph">
                    <span className="pt"><FileCheck2 size={12} /> {label}</span>
                    <button className="cp" onClick={() => copy(body || "", key)}>
                      {copied === key ? <><Check size={11} /> copied</> : <><Copy size={11} /> copy</>}
                    </button>
                  </div>
                  <div className="pb">{body || "—"}</div>
                </div>)}
            </div>
          </aside>
        </>}

      {copied && <div className="toast"><Check size={14} /> Copied to clipboard</div>}
    </div>
  );
}
