# VulneraSight AI

Threat-informed cyber risk correlation engine. Ingests a Nessus scan (`.nessus`)
and a STIG Viewer checklist (`.ckl`), re-weights every finding through the system's
real connectivity context, and generates a prioritized remediation roadmap plus
POA&M language. The analysis is powered by Claude via a small server-side proxy.

This is a standard **Vite + React** front end with a tiny **Express** backend whose
only job is to hold your API key and forward requests. The key never reaches the
browser. The backend is **provider-agnostic**: it works with Anthropic (Claude),
Ask Sage, Google Gemini, or any OpenAI-compatible endpoint — you choose with one
env variable, no code changes.

---

## Prerequisites

- **Node.js 18 or newer** (`node -v` to check). Node 18+ ships a global `fetch`,
  which the proxy uses.
- An **API key** for whichever provider you choose (Anthropic, Ask Sage, Gemini, …).

## Setup

```bash
npm install
cp .env.example .env        # then edit .env: choose AI_PROVIDER and set AI_API_KEY
```

## Choosing a provider (no code changes)

You don't have to use Anthropic. Set `AI_PROVIDER` in `.env` to one of
`anthropic`, `asksage`, `gemini`, or `openai`, then set `AI_API_KEY`. The proxy
builds the right request and normalizes the reply so the UI is identical
regardless of provider.

| `AI_PROVIDER` | Default base URL | Auth | Default model |
|---|---|---|---|
| `anthropic` | `https://api.anthropic.com` | `x-api-key` | `claude-sonnet-4-6` |
| `asksage` | `https://api.asksage.ai/server/openai/v1` | `Bearer` | `gpt-4.1-mini` |
| `gemini` | `https://generativelanguage.googleapis.com/v1beta/openai` | `Bearer` | `gemini-2.5-flash` |
| `openai` | `https://api.openai.com/v1` | `Bearer` | `gpt-4o` |

Override the model with `AI_MODEL` and the endpoint with `AI_BASE_URL` (needed for
Ask Sage GovCloud/IL instances — only the instance segment of the URL changes — or
for regional/internal gateways). Ask Sage and Gemini are reached through their
**OpenAI-compatible** chat-completions endpoints, so the same adapter also covers
OpenAI, Azure OpenAI, and most other OpenAI-style providers.

Examples for `.env`:

```ini
# Ask Sage
AI_PROVIDER=asksage
AI_API_KEY=your-asksage-api-key
AI_MODEL=gpt-4.1-mini

# Gemini (key from Google AI Studio)
AI_PROVIDER=gemini
AI_API_KEY=your-gemini-api-key
AI_MODEL=gemini-2.5-flash
```

Check what's active any time at `GET /api/health` (reports provider, model,
base URL, and whether a key is configured).

## Run in development (hot reload)

```bash
npm run dev
```

- React dev server: http://localhost:5173  ← open this
- API proxy:        http://localhost:8787  (Vite forwards `/api/*` to it automatically)

Both start together. Edit anything in `src/` and it hot-reloads.

## Run in production (single process)

```bash
npm run build      # outputs static files to dist/
npm start          # serves the built UI AND /api on one port (default 8787)
```

Then open http://localhost:8787. Set `PORT` in `.env` to change the port.

---

## How it fits together

```
Browser (React app)
   │  POST /api/analyze   { system, messages, max_tokens }
   ▼
Express proxy (server/index.js)    ← reads AI_PROVIDER + AI_API_KEY from .env
   │  builds the provider's request, attaches the key
   ▼
Anthropic / Ask Sage / Gemini / OpenAI  → reply normalized to the
                                           Anthropic shape the UI expects
```

File parsing (`.nessus` / `.ckl`), the connectivity-based risk adjustment, the
threat radar, the tradespace planner, and CSV export all run **in the browser**.
Only the de-identified findings summary is sent to the model (and IPs/hostnames
are redacted first when "Data masking" is on).

## Configuration (set in `.env`)

| Variable | Default | Purpose |
|---|---|---|
| `AI_PROVIDER` | `anthropic` | `anthropic` \| `asksage` \| `gemini` \| `openai`. |
| `AI_API_KEY` | — | **Required.** Key for the chosen provider. |
| `AI_MODEL` | per provider | Override the model. |
| `AI_BASE_URL` | per provider | Override the endpoint (instance/region/gateway). |
| `PORT` | `8787` | Backend / production server port. |

(For backward compatibility the proxy also accepts `ANTHROPIC_API_KEY`,
`CLAUDE_MODEL`, and `ANTHROPIC_BASE_URL` when the provider is `anthropic`.)

---

## Deploying elsewhere

- **Any Node host / Docker / VM:** run `npm run build` then `npm start`. One process
  serves both the UI and the API. Provide the env vars through your platform.
- **Serverless (Vercel/Netlify/Lambda):** deploy `dist/` as a static site and port
  the `/api/analyze` handler in `server/index.js` into a serverless function. Keep
  the key in the platform's secret store, never in the client bundle.
- **Air-gapped / restricted networks:** the app's *analysis* is the only part that
  needs to reach a model. Set `AI_PROVIDER`/`AI_BASE_URL` to an approved provider —
  e.g. an **Ask Sage** GovCloud/IL instance (just change the instance segment of the
  base URL), or an internal Claude/Bedrock/Vertex gateway. Everything else runs
  fully offline in the browser.

## Embedding into an existing React app

`src/App.jsx` is a single self-contained component (it injects its own CSS and uses
only `react`, `recharts`, and `lucide-react`). To drop it into another React
project: copy `App.jsx`, `npm install recharts lucide-react`, render `<App />`, and
make sure a `POST /api/analyze` proxy like the one in `server/index.js` exists on
the same origin.

## Security notes

- The API key lives only on the server, loaded from `.env` (which is git-ignored).
- Never expose the key to the browser or commit `.env`.
- The proxy forwards only `system`, `messages`, and `max_tokens` to the model.
- Treat AI-generated POA&M text as a draft for analyst review before submission.

## Project layout

```
vulnerasight/
├─ index.html
├─ package.json
├─ vite.config.js          # dev server + /api proxy
├─ .env.example            # copy to .env
├─ server/
│  └─ index.js             # Express proxy (holds the key) + static serving
└─ src/
   ├─ main.jsx
   ├─ index.css
   └─ App.jsx              # the full VulneraSight application
```
